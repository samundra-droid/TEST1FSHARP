﻿
// For more information see https://aka.ms/fsharp-console-apps
let employeeSalaries = [75000; 48000; 120000; 190000; 300113; 92000; 36000]

// Display the list of employee salaries
employeeSalaries |> List.iter (printfn "Employee salary: %d")

// Filter high-income salaries (above $100,000)
let highEarningSalaries = employeeSalaries |> List.filter (fun salary -> salary > 100000)
highEarningSalaries |> List.iter (printfn "High-earning salary: %d")

// Function to calculate tax based on the provided tax brackets
let calculateTax salary =
    match salary with
    | _ when salary <= 49020 -> float salary * 0.15
    | _ when salary <= 98040 -> float salary * 0.205
    | _ when salary <= 151978 -> float salary * 0.26
    | _ when salary <= 216511 -> float salary * 0.29
    | _ -> float salary * 0.33

// Calculate the tax for all salaries
let taxedEmployeeSalaries = employeeSalaries |> List.map calculateTax

// Display the taxed salaries
taxedEmployeeSalaries |> List.iter (printfn "Calculated tax on salary: %.2f")

// Filter salaries less than $49,020
let lowIncomeSalaries = employeeSalaries |> List.filter (fun salary -> salary < 49020)
lowIncomeSalaries |> List.iter (printfn "Low income salary: %d")

// Add $20,000 to the filtered salaries
let boostedSalaries = lowIncomeSalaries |> List.map (fun salary -> salary + 20000)
boostedSalaries |> List.iter (printfn "Boosted salary: %d")

printfn""

// Filter salaries between $50,000 and $100,000
let midRangeSalaries = employeeSalaries |> List.filter (fun salary -> salary >= 50000 && salary <= 100000)
midRangeSalaries |> List.iter (printfn "Mid-range salary: %d")

// Sum of salaries in the range
let totalMidRangeSum = midRangeSalaries |> List.fold (fun acc salary -> acc + salary) 0
printfn "Total sum of mid-range salaries: %d" totalMidRangeSum

let sumMultiplesOfNTailRec(n: int) =
    let rec helper (current: int) (acc: int) =
        if current <= 0 then acc
        else helper (current - 3) (acc + current)
    helper n 0

let result = sumMultiplesOfNTailRec 9
printfn "The total sum of all multiples of 3 till 9 is %d" result